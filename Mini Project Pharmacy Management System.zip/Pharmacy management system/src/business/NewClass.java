package business;

/**
 *
 * @author chandanaanandrangappa
 */
public class NewClass {
    
}
